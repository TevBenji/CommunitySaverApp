# Community Savings Web Application

A modern web application for managing community savings groups (partner plans/sou-sous) with a trust-based tier system.

## Features

### Trust Score System
- Each user starts with a Trust Score of 300 (max 999)
- Score increases with good behavior:
  - +10 for on-time payments
  - +30 for completing a cycle
- Score decreases with penalties:
  - -100 for late payments
  - -200 for defaults or early exits

### Trust Score Tiers
- **Low Tier (0-499)**: Can join 1 group max
- **Medium Tier (500-749)**: Can join 2 groups max
- **High Tier (750-999)**: Can join 3+ groups

### Group Management
- Create public or private savings groups
- Set contribution amounts and frequencies
- Define minimum trust score requirements
- Automated payment tracking and scheduling
- Real-time contribution and payout logs

### Security Features
- Supabase Authentication
- Encrypted data in transit and at rest
- Comprehensive audit trails through Supabase

## Tech Stack

- **Frontend**: React with Vite
- **Backend**: Supabase
- **Database**: PostgreSQL (via Supabase)
- **Authentication**: Supabase Auth
- **UI Components**: shadcn/ui
- **Styling**: Tailwind CSS

## Database Schema

### Profiles
- Trust Score management
- User details
- Group membership tracking

### Savings Groups
- Group configuration
- Member management
- Payment schedules

### Group Members
- Group membership status
- Payout order tracking
- Payment history

### Payments
- Payment records
- Status management
- Due date tracking

### Join Requests
- Group join request management
- Request status tracking

## Getting Started

### Prerequisites
- Node.js 18+
- Supabase Account

### Installation
1. Clone the repository
2. Install dependencies:
```bash
npm install
```

3. Run the development server:
```bash
npm run dev
```

## Contributing

Please contact the project maintainers for details on contributing to this project.

## License

This project is proprietary and confidential. All rights reserved.