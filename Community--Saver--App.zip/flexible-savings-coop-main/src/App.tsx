import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Layout from "./components/layout/Layout";
import Index from "./pages/Index";
import Dashboard from "./pages/Dashboard";
import GroupDetails from "./pages/GroupDetails";
import Profile from "./pages/Profile";
import Payments from "./pages/Payments";
import Analytics from "./pages/Analytics";
import Activity from "./pages/Activity";
import CreateGroupPage from "./pages/CreateGroupPage";
import Groups from "./pages/Groups";
import AIAdvisor from "./pages/AIAdvisor";
import Messages from "./pages/Messages";
import Achievements from "./pages/Achievements";

const queryClient = new QueryClient();

const App = () => {
  // Force dark mode by adding the class to the document root
  React.useEffect(() => {
    document.documentElement.classList.add('dark');
  }, []);

  return (
    <React.StrictMode>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <div className="min-h-screen transition-colors duration-300">
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/dashboard" element={<Layout><Dashboard /></Layout>} />
                <Route path="/groups" element={<Layout><Groups /></Layout>} />
                <Route path="/groups/:id" element={<Layout><GroupDetails /></Layout>} />
                <Route path="/profile" element={<Layout><Profile /></Layout>} />
                <Route path="/profile/:id" element={<Layout><Profile /></Layout>} />
                <Route path="/payments" element={<Layout><Payments /></Layout>} />
                <Route path="/analytics" element={<Layout><Analytics /></Layout>} />
                <Route path="/activity" element={<Layout><Activity /></Layout>} />
                <Route path="/create-group" element={<Layout><CreateGroupPage /></Layout>} />
                <Route path="/ai-advisor" element={<Layout><AIAdvisor /></Layout>} />
                <Route path="/messages" element={<Layout><Messages /></Layout>} />
                <Route path="/achievements" element={<Layout><Achievements /></Layout>} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </BrowserRouter>
          </div>
        </TooltipProvider>
      </QueryClientProvider>
    </React.StrictMode>
  );
};

export default App;