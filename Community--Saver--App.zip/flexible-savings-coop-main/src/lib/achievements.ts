import { supabase } from "@/integrations/supabase/client";

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  points: number;
  category: 'savings' | 'group' | 'trust' | 'activity';
  requirements: {
    type: string;
    value: number;
  };
  unlockedAt?: string;
}

export const achievements: Achievement[] = [
  {
    id: 'first_group',
    title: 'Group Pioneer',
    description: 'Join your first savings group',
    icon: 'users',
    points: 100,
    category: 'group',
    requirements: {
      type: 'groups_joined',
      value: 1
    }
  },
  {
    id: 'savings_milestone_1',
    title: 'Savings Starter',
    description: 'Save your first $100',
    icon: 'piggy-bank',
    points: 150,
    category: 'savings',
    requirements: {
      type: 'total_savings',
      value: 100
    }
  },
  {
    id: 'trust_score_50',
    title: 'Trusted Member',
    description: 'Reach a trust score of 50',
    icon: 'shield',
    points: 200,
    category: 'trust',
    requirements: {
      type: 'trust_score',
      value: 50
    }
  },
  {
    id: 'perfect_payments',
    title: 'Reliable Contributor',
    description: 'Make 10 payments on time',
    icon: 'check-circle',
    points: 300,
    category: 'activity',
    requirements: {
      type: 'on_time_payments',
      value: 10
    }
  }
];

export const checkAchievements = async (userId: string) => {
  try {
    // Fetch user's profile and activity data
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*, group_members(group_id)')
      .eq('id', userId)
      .single();

    if (profileError) throw profileError;

    const { data: payments, error: paymentsError } = await supabase
      .from('payments')
      .select('amount, status, is_late')
      .eq('member_id', userId);

    if (paymentsError) throw paymentsError;

    const { data: existingAchievements, error: achievementsError } = await supabase
      .from('user_achievements')
      .select('achievement_id, unlocked_at')
      .eq('user_id', userId)
      .returns<Array<{ achievement_id: string; unlocked_at: string }>>();

    if (achievementsError) throw achievementsError;

    const unlockedAchievements = existingAchievements ? existingAchievements.map(a => a.achievement_id) : [];
    const newAchievements: Achievement[] = [];

    // Check each achievement
    for (const achievement of achievements) {
      if (unlockedAchievements.includes(achievement.id)) continue;

      let isUnlocked = false;
      switch (achievement.requirements.type) {
        case 'groups_joined':
          isUnlocked = (profile?.groups_joined || 0) >= achievement.requirements.value;
          break;
        case 'total_savings':
          const totalSavings = payments?.reduce((sum, p) => sum + (p.amount || 0), 0) || 0;
          isUnlocked = totalSavings >= achievement.requirements.value;
          break;
        case 'trust_score':
          isUnlocked = (profile?.trust_score || 0) >= achievement.requirements.value;
          break;
        case 'on_time_payments':
          const onTimePayments = payments?.filter(p => p.status === 'completed' && !p.is_late)?.length || 0;
          isUnlocked = onTimePayments >= achievement.requirements.value;
          break;
      }

      if (isUnlocked) {
        // Add to user's achievements
        await supabase
          .from('user_achievements')
          .insert({
            user_id: userId,
            achievement_id: achievement.id,
            unlocked_at: new Date().toISOString()
          });

        newAchievements.push(achievement);
      }
    }

    return newAchievements;
  } catch (error: any) {
    console.error('Error checking achievements:', error);
    throw new Error(`Failed to check achievements: ${error.message}`);
  }
};