import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import SearchBar from "./SearchBar";
import SearchResults from "./SearchResults";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useDebounce } from "@/hooks/use-debounce";

const SearchSection = () => {
  const [searchType, setSearchType] = useState<"groups" | "profiles">("groups");
  const [searchQuery, setSearchQuery] = useState("");
  const debouncedQuery = useDebounce(searchQuery, 300);

  const { data: searchResults = [], isLoading } = useQuery({
    queryKey: ["search", searchType, debouncedQuery],
    queryFn: async () => {
      console.log("Searching for:", { type: searchType, query: debouncedQuery });
      
      if (!debouncedQuery) return [];

      if (searchType === "groups") {
        const { data, error } = await supabase
          .from("savings_groups")
          .select("*")
          .ilike("name", `%${debouncedQuery}%`)
          .eq('status', 'active')
          .limit(10);

        if (error) {
          console.error("Search error:", error);
          return [];
        }

        console.log("Search results:", data);
        return data || [];
      } else {
        const { data, error } = await supabase
          .from("profiles")
          .select("*, current_groups_joined")
          .or(`first_name.ilike.%${debouncedQuery}%,last_name.ilike.%${debouncedQuery}%`)
          .limit(10);

        if (error) {
          console.error("Search error:", error);
          return [];
        }

        return data || [];
      }
    },
    enabled: debouncedQuery.length > 0,
  });

  const handleSearch = (value: string) => {
    console.log("Search input changed:", value);
    setSearchQuery(value);
  };

  return (
    <div className="space-y-4">
      <Tabs defaultValue="groups" onValueChange={(value) => setSearchType(value as "groups" | "profiles")}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="groups">Search Groups</TabsTrigger>
          <TabsTrigger value="profiles">Search Profiles</TabsTrigger>
        </TabsList>
        <TabsContent value="groups">
          <SearchBar
            placeholder="Search for savings groups..."
            value={searchQuery}
            onChange={handleSearch}
          />
        </TabsContent>
        <TabsContent value="profiles">
          <SearchBar
            placeholder="Search for users..."
            value={searchQuery}
            onChange={handleSearch}
          />
        </TabsContent>
      </Tabs>
      
      {debouncedQuery && (
        <SearchResults
          type={searchType}
          results={searchResults}
          onClose={() => setSearchQuery("")}
          isLoading={isLoading}
        />
      )}
    </div>
  );
};

export default SearchSection;