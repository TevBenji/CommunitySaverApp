import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { Eye, Loader2 } from "lucide-react";

interface SearchResultsProps {
  type: "groups" | "profiles";
  results: any[];
  onClose: () => void;
  isLoading?: boolean;
}

const SearchResults = ({ type, results, onClose, isLoading }: SearchResultsProps) => {
  const navigate = useNavigate();

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  const handleProfileClick = (profileId: string) => {
    console.log("Navigating to profile:", profileId);
    navigate(`/profile/${profileId}`);
    onClose();
  };

  const handleGroupClick = (groupId: string) => {
    navigate(`/groups/${groupId}`);
    onClose();
  };

  if (isLoading) {
    return (
      <Card className="p-4 bg-white/50 backdrop-blur-sm border-primary/20">
        <div className="flex items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </div>
      </Card>
    );
  }

  if (results.length === 0) {
    return (
      <Card className="p-4 bg-white/50 backdrop-blur-sm border-primary/20">
        <p className="text-center text-primary/60">No results found</p>
      </Card>
    );
  }

  return (
    <Card className="p-4 space-y-2 bg-white/50 backdrop-blur-sm border-primary/20 max-h-[300px] overflow-y-auto">
      {type === "profiles" ? (
        results.map((profile) => (
          <div
            key={profile.id}
            onClick={() => handleProfileClick(profile.id)}
            className="flex items-center justify-between p-2 hover:bg-primary/5 rounded-lg transition-colors cursor-pointer"
          >
            <div className="flex items-center space-x-3">
              <Avatar>
                <AvatarFallback>
                  {getInitials(profile.first_name, profile.last_name)}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium text-primary">
                  {profile.first_name} {profile.last_name}
                </p>
                <p className="text-sm text-primary/60">
                  Trust Score: {profile.trust_score}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="secondary">
                {profile.current_groups_joined} Groups
              </Badge>
              <Eye className="h-4 w-4 text-primary/60" />
            </div>
          </div>
        ))
      ) : (
        results.map((group) => (
          <div
            key={group.id}
            onClick={() => handleGroupClick(group.id)}
            className="flex items-center justify-between p-2 hover:bg-primary/5 rounded-lg transition-colors cursor-pointer"
          >
            <div>
              <p className="font-medium text-primary">{group.name}</p>
              <p className="text-sm text-primary/60">
                Min Trust Score: {group.min_trust_score}
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <Badge 
                className={`${
                  group.group_tier === 'high' 
                    ? 'bg-gradient-to-r from-[#2D1810] to-[#8B4513] text-white'
                    : group.group_tier === 'medium'
                    ? 'bg-gradient-to-r from-[#C19A6B] to-[#DAA520] text-white'
                    : 'bg-gradient-to-r from-[#F1F0FB] to-[#D3E4FD] text-primary'
                }`}
              >
                {group.group_tier.toUpperCase()} TIER
              </Badge>
              <Eye className="h-4 w-4 text-primary/60" />
            </div>
          </div>
        ))
      )}
    </Card>
  );
};

export default SearchResults;