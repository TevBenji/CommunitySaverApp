import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

interface SearchBarProps {
  placeholder: string;
  value: string;
  onChange: (value: string) => void;
}

const SearchBar = ({ placeholder, value, onChange }: SearchBarProps) => {
  return (
    <div className="relative">
      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
      <Input
        type="text"
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="pl-9 py-2 bg-gray-800/50 border-gray-700/50 
                   text-white placeholder:text-gray-500 
                   text-sm rounded-lg
                   focus:ring-2 focus:ring-blue-500/50"
      />
    </div>
  );
};

export default SearchBar;