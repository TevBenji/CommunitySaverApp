import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Trophy, Shield, Users, PiggyBank, CheckCircle } from 'lucide-react';
import { Achievement } from '@/lib/achievements';

interface AchievementCardProps {
  achievement: Achievement;
  progress?: number;
  isUnlocked?: boolean;
}

const iconMap = {
  'users': Users,
  'shield': Shield,
  'piggy-bank': PiggyBank,
  'check-circle': CheckCircle,
  'trophy': Trophy
};

const AchievementCard: React.FC<AchievementCardProps> = ({
  achievement,
  progress = 0,
  isUnlocked = false
}) => {
  const Icon = iconMap[achievement.icon as keyof typeof iconMap] || Trophy;

  return (
    <Card className={`relative overflow-hidden transition-all duration-300 ${isUnlocked ? 'bg-gradient-to-br from-blue-600/20 to-purple-600/20' : 'bg-gray-900/90'} hover:scale-[1.02] hover:shadow-lg border-gray-800/50`}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-3">
              <div className={`p-2 rounded-lg ${isUnlocked ? 'bg-blue-500/20 text-blue-400' : 'bg-gray-800/50 text-gray-400'}`}>
                <Icon className="w-5 h-5" />
              </div>
              <h3 className={`font-semibold ${isUnlocked ? 'text-blue-400' : 'text-gray-300'}`}>
                {achievement.title}
              </h3>
            </div>
            <p className="text-sm text-gray-400 mb-4">{achievement.description}</p>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Progress</span>
                <span className={`font-medium ${isUnlocked ? 'text-blue-400' : 'text-gray-300'}`}>
                  {progress}%
                </span>
              </div>
              <Progress
                value={progress}
                className={`h-2 ${isUnlocked ? 'bg-gradient-to-r from-blue-500 to-purple-500' : ''}`}
              />
            </div>
          </div>
        </div>
        {isUnlocked && (
          <div className="absolute top-3 right-3">
            <div className="p-1.5 rounded-full bg-blue-500/20">
              <Trophy className="w-4 h-4 text-blue-400" />
            </div>
          </div>
        )}
        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className={`px-2 py-1 rounded-full text-xs font-medium ${isUnlocked ? 'bg-blue-500/20 text-blue-400' : 'bg-gray-800/50 text-gray-400'}`}>
              {achievement.category}
            </div>
          </div>
          <div className={`text-sm font-medium ${isUnlocked ? 'text-blue-400' : 'text-gray-400'}`}>
            {achievement.points} points
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AchievementCard;