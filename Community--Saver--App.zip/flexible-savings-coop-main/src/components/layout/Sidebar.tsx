import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  Users,
  Wallet,
  BarChart2,
  Bot,
  MessageSquare,
  Trophy,
  User,
  Menu,
  X,
  ChevronDown,
} from "lucide-react";
import { cn } from "@/lib/utils";

const menuItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard" },
  { icon: Users, label: "Groups", path: "/groups" },
  { icon: Wallet, label: "Payments", path: "/payments" },
  { icon: BarChart2, label: "Analytics", path: "/analytics" },
  { icon: Bot, label: "AI Advisor", path: "/ai-advisor" },
  { icon: MessageSquare, label: "Messages", path: "/messages" },
  { icon: Trophy, label: "Achievements", path: "/achievements" },
  { icon: User, label: "Profile", path: "/profile" },
];

const Sidebar = () => {
  const location = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <header 
        className={cn(
          "fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b",
          isScrolled 
            ? "bg-gray-900/95 backdrop-blur-md shadow-lg border-gray-800/50" 
            : "bg-gray-900/80 backdrop-blur-sm border-transparent"
        )}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between gap-6">
            <div className="flex items-center gap-6">
              <Link 
                to="/dashboard" 
                className="flex items-center gap-3 text-lg sm:text-xl font-bold text-white shrink-0"
              >
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center shadow-lg">
                  <span className="text-white font-bold text-lg">C</span>
                </div>
                <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent hidden sm:inline-block">
                  CommunitySaver
                </span>
              </Link>
            </div>
      
            <nav className="hidden md:flex items-center space-x-6 overflow-x-auto scrollbar-hide">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
      
                return (
                  <Link key={item.path} to={item.path}>
                    <Button
                      variant={isActive ? "secondary" : "ghost"}
                      className={cn(
                        "flex items-center px-5 py-2.5 rounded-lg transition-all duration-200 text-sm",
                        isActive 
                          ? "bg-gray-800/80 text-white shadow-lg hover:bg-gray-700/80" 
                          : "text-gray-300 hover:text-white hover:bg-gray-800/50"
                      )}
                    >
                      <Icon className={cn(
                        "h-4 w-4 mr-3",
                        isActive ? "text-blue-400" : "text-gray-400"
                      )} />
                      <span>{item.label}</span>
                    </Button>
                  </Link>
                );
              })}
            </nav>

            <div className="md:hidden">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-white hover:bg-gray-800/50 p-2"
              >
                {isMobileMenuOpen ? (
                  <X className="h-5 w-5" />
                ) : (
                  <Menu className="h-5 w-5" />
                )}
              </Button>
            </div>
          </div>
        </div>
      
        {/* Mobile Menu */}
        <div className={cn(
          "md:hidden fixed inset-x-0 bg-gray-900/95 backdrop-blur-md transition-all duration-300 ease-in-out shadow-lg border-t border-gray-800/50",
          isMobileMenuOpen ? "top-[60px] opacity-100" : "-top-full opacity-0"
        )}>
          <nav className="max-w-7xl mx-auto py-3 px-4 space-y-1.5">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
      
              return (
                <Link 
                  key={item.path} 
                  to={item.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Button
                    variant={isActive ? "secondary" : "ghost"}
                    className={cn(
                      "w-full flex items-center px-3 py-2 rounded-lg transition-all duration-200 text-sm",
                      isActive 
                        ? "bg-gray-800/80 text-white shadow-lg hover:bg-gray-700/80" 
                        : "text-gray-300 hover:text-white hover:bg-gray-800/50"
                    )}
                  >
                    <Icon className={cn(
                      "h-4 w-4 mr-2",
                      isActive ? "text-blue-400" : "text-gray-400"
                    )} />
                    <span>{item.label}</span>
                  </Button>
                </Link>
              );
            })}
          </nav>
        </div>
      </header>
      <div className="h-16" /> {/* Spacer to prevent content from being hidden under fixed header */}
    </>
  );
};

export default Sidebar;