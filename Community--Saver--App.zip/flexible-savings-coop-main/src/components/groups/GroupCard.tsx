import { useNavigate } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useState } from "react";
import { Loader2 } from "lucide-react";

interface GroupCardProps {
  id?: string;
  name: string;
  members: number;
  contribution: number;
  totalAmount: number;
  minTrustScore: number;
  groupTier: string;
  maxMembers?: number;
  userTrustScore?: number;
}

const GroupCard = ({
  id,
  name,
  members,
  contribution,
  totalAmount,
  minTrustScore,
  groupTier,
  maxMembers = 10,
  userTrustScore = 0,
}: GroupCardProps) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isJoining, setIsJoining] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleJoinGroup = async () => {
    if (!id) return;
    
    try {
      setIsJoining(true);
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        toast({
          title: "Error",
          description: "You must be logged in to join a group",
          variant: "destructive",
        });
        return;
      }

      // Check if user is already a member
      const { data: existingMember } = await supabase
        .from('group_members')
        .select('*')
        .eq('group_id', id)
        .eq('member_id', user.id)
        .single();

      if (existingMember) {
        toast({
          title: "Already a member",
          description: "You are already a member of this group",
          variant: "destructive",
        });
        return;
      }

      // Check for existing join request
      const { data: existingRequest } = await supabase
        .from('join_requests')
        .select('*')
        .eq('group_id', id)
        .eq('user_id', user.id)
        .single();

      if (existingRequest) {
        toast({
          title: "Request Pending",
          description: "You already have a pending request for this group",
        });
        return;
      }

      // Create join request
      const { error: joinRequestError } = await supabase
        .from('join_requests')
        .insert({
          group_id: id,
          user_id: user.id,
          status: 'pending'
        });

      if (joinRequestError) throw joinRequestError;

      toast({
        title: "Success",
        description: "Your request to join has been sent",
      });
    } catch (error: any) {
      console.error('Error joining group:', error);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsJoining(false);
    }
  };

  const handleViewDetails = () => {
    if (!isEligible) {
      toast({
        title: "Insufficient Trust Score",
        description: `You need a Trust Score of ${minTrustScore}+ to view this group.`,
        variant: "destructive",
      });
      return;
    }
    
    if (id) {
      setIsLoading(true);
      navigate(`/groups/${id}`);
    }
  };

  const getTierColor = (tier: string) => {
    switch (tier.toLowerCase()) {
      case 'high':
        return 'bg-gradient-to-r from-[#2D1810] to-[#8B4513] text-white';
      case 'medium':
        return 'bg-gradient-to-r from-[#C19A6B] to-[#DAA520] text-white';
      case 'low':
        return 'bg-gradient-to-r from-[#F1F0FB] to-[#D3E4FD] text-primary';
      default:
        return 'bg-secondary/10 text-secondary';
    }
  };

  const isEligible = userTrustScore >= minTrustScore;

  return (
    <Card 
      className={`p-6 space-y-4 animate-scaleIn bg-card-gradient backdrop-blur-sm border border-white/20 shadow-sm card-hover ${
        !isEligible ? 'opacity-50' : ''
      }`} 
    >
      <div className="flex justify-between items-start">
        <div className="space-y-2">
          <h3 className="text-xl font-semibold text-primary">{name}</h3>
          <Badge className={`${getTierColor(groupTier)} shadow-sm`}>
            {groupTier.toUpperCase()} TIER
          </Badge>
        </div>
        <span className="px-3 py-1.5 bg-accent rounded-full text-sm font-medium text-primary">
          {members}/{maxMembers}
        </span>
      </div>
      
      <div className="space-y-3">
        <div className="flex justify-between items-center p-3 bg-white/50 rounded-lg">
          <span className="text-sm text-primary/80">Monthly Contribution</span>
          <span className="font-semibold text-primary">${contribution}</span>
        </div>
        <div className="flex justify-between items-center p-3 bg-white/50 rounded-lg">
          <span className="text-sm text-primary/80">Total Amount</span>
          <span className="font-semibold text-primary">${totalAmount}</span>
        </div>
        <div className="flex justify-between items-center p-3 bg-white/50 rounded-lg">
          <span className="text-sm text-primary/80">Min Trust Score</span>
          <span className="font-semibold text-primary">{minTrustScore}</span>
        </div>
      </div>
      
      <div className="space-y-2 pt-2">
        <Button 
          onClick={handleViewDetails}
          className={`w-full h-12 text-base font-medium ${
            isEligible 
              ? 'bg-[#8B4513] hover:bg-[#2D1810] text-white shadow-md transition-colors duration-200' 
              : 'bg-gray-400'
          }`}
          disabled={!isEligible || isLoading}
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Loading...
            </>
          ) : (
            'View Details'
          )}
        </Button>
        {isEligible && (
          <Button 
            onClick={handleJoinGroup}
            className="w-full h-12 text-base font-medium bg-[#DAA520] hover:bg-[#C19A6B] text-white shadow-md transition-colors duration-200"
            disabled={isJoining}
          >
            {isJoining ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Joining...
              </>
            ) : (
              'Join Group'
            )}
          </Button>
        )}
      </div>
    </Card>
  );
};

export default GroupCard;
