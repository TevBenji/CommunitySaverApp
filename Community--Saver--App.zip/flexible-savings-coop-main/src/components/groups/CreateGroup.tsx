import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useNavigate } from "react-router-dom";

const CreateGroup = () => {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [contribution, setContribution] = useState("");
  const [minTrustScore, setMinTrustScore] = useState("");
  const [groupTier, setGroupTier] = useState("low");
  const [frequency, setFrequency] = useState("monthly");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        toast({
          title: "Error",
          description: "You must be logged in to create a group",
          variant: "destructive",
        });
        return;
      }

      // Validate inputs
      if (!name.trim()) {
        throw new Error("Group name is required");
      }

      const contributionAmount = parseFloat(contribution);
      if (isNaN(contributionAmount) || contributionAmount <= 0) {
        throw new Error("Please enter a valid contribution amount");
      }

      const trustScore = parseInt(minTrustScore);
      if (isNaN(trustScore) || trustScore < 0) {
        throw new Error("Please enter a valid minimum trust score");
      }

      const { data, error } = await supabase
        .from('savings_groups')
        .insert({
          name: name.trim(),
          description: description.trim(),
          contribution_amount: contributionAmount,
          min_trust_score: trustScore,
          group_tier: groupTier,
          banker_id: user.id,
          frequency: frequency,
          status: 'not_started'
        })
        .select()
        .single();

      if (error) throw error;

      toast({
        title: "Success",
        description: "Group created successfully!",
      });

      // Reset form
      setName("");
      setDescription("");
      setContribution("");
      setMinTrustScore("");
      setGroupTier("low");
      setFrequency("monthly");

      // Navigate to the new group's details page
      if (data) {
        navigate(`/groups/${data.id}`);
      }
    } catch (error: any) {
      console.error('Error creating group:', error);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="p-6 space-y-4 animate-fadeIn">
      <h2 className="text-2xl font-bold text-primary">Create New Group</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <label htmlFor="name" className="text-sm font-medium">
            Group Name
          </label>
          <Input
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            placeholder="Enter group name"
            disabled={isLoading}
          />
        </div>
        <div className="space-y-2">
          <label htmlFor="description" className="text-sm font-medium">
            Description
          </label>
          <Textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Enter group description"
            disabled={isLoading}
            className="min-h-[100px]"
          />
        </div>
        <div className="space-y-2">
          <label htmlFor="contribution" className="text-sm font-medium">
            Contribution Amount ($)
          </label>
          <Input
            id="contribution"
            type="number"
            value={contribution}
            onChange={(e) => setContribution(e.target.value)}
            required
            placeholder="Enter contribution amount"
            disabled={isLoading}
            min="0"
            step="0.01"
          />
        </div>
        <div className="space-y-2">
          <label htmlFor="frequency" className="text-sm font-medium">
            Contribution Frequency
          </label>
          <Select
            value={frequency}
            onValueChange={setFrequency}
            disabled={isLoading}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select frequency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="bi-weekly">Bi-weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <label htmlFor="minTrustScore" className="text-sm font-medium">
            Minimum Trust Score
          </label>
          <Input
            id="minTrustScore"
            type="number"
            value={minTrustScore}
            onChange={(e) => setMinTrustScore(e.target.value)}
            required
            placeholder="Enter minimum trust score"
            disabled={isLoading}
            min="0"
          />
        </div>
        <div className="space-y-2">
          <label htmlFor="groupTier" className="text-sm font-medium">
            Group Tier
          </label>
          <Select
            value={groupTier}
            onValueChange={setGroupTier}
            disabled={isLoading}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select group tier" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Creating...
            </>
          ) : (
            'Create Group'
          )}
        </Button>
      </form>
    </Card>
  );
};

export default CreateGroup;