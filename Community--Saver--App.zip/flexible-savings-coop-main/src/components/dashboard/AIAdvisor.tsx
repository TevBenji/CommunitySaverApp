import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Brain } from "lucide-react";

const AIAdvisor = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [advice, setAdvice] = useState<string | null>(null);

  const { data: profile } = useQuery({
    queryKey: ["profile"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single();
      
      if (error) throw error;
      return data;
    },
  });

  const getAIAdvice = async () => {
    try {
      setIsLoading(true);
      
      const context = `User trust score: ${profile?.trust_score}
        Number of groups: ${profile?.current_groups_joined}`;
      
      const { data, error } = await supabase.functions.invoke('ai-advisor', {
        body: {
          prompt: "Based on my profile, what financial advice can you give me about joining or managing savings groups?",
          context: context
        }
      });

      if (error) throw error;

      const aiAdvice = data.choices[0].message.content;
      setAdvice(aiAdvice);
    } catch (error) {
      console.error('Error getting AI advice:', error);
      setAdvice("Failed to get AI advice. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const formatAdviceText = (text: string) => {
    return text.split('\n\n').map((paragraph) => {
      return paragraph
        .replace(/^###\s*\d+\.\s*\*\*(.*?)\*\*$/gm, '$1')  // Remove ### and ** from titles
        .trim();
    }).filter(Boolean);
  };

  return (
    <Card className="bg-card-gradient-dark border border-gray-800/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Brain className="h-5 w-5 text-blue-400" />
          AI Financial Advisor
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-gray-400">
          Get personalized financial advice based on your profile and savings group activity.
        </p>
        <Button 
          onClick={getAIAdvice}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Getting Advice...
            </>
          ) : (
            'Get AI Advice'
          )}
        </Button>
        
        {advice && (
          <div className="mt-6 rounded-xl bg-gray-900/60 border border-gray-800/50 backdrop-blur-sm animate-fadeIn overflow-hidden">
            <div className="max-h-[400px] overflow-y-auto p-6 scrollbar-thin scrollbar-thumb-blue-600 scrollbar-track-gray-800">
              <div className="space-y-6">
                {formatAdviceText(advice).map((paragraph, index) => (
                  <div key={index} 
                    className="p-4 rounded-lg bg-gray-800/40 border border-gray-700/30 transition-all duration-300 hover:bg-gray-800/60">
                    <p className="text-sm sm:text-base font-medium text-gray-200 leading-relaxed">
                      {paragraph}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AIAdvisor;