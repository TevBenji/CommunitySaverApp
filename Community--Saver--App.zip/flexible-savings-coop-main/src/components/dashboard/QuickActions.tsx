import { useNavigate } from "react-router-dom";
import { DollarSign, UserCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";

const QuickActions = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleNavigation = async (path: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Authentication required",
          description: "Please log in to access this feature",
          variant: "destructive",
        });
        navigate('/');
        return;
      }
      navigate(path);
    } catch (error) {
      console.error("Navigation error:", error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="grid grid-cols-2 gap-2 w-full">
      <button
        onClick={() => handleNavigation('/payments')}
        className="flex items-center justify-center gap-2 w-full bg-gray-800/50 
                 hover:bg-gray-700/50 text-white rounded-xl p-3 
                 border border-gray-700/50 transition-all duration-200
                 hover:border-gray-600/50"
      >
        <DollarSign className="h-4 w-4" />
        <span className="font-medium">Payments</span>
      </button>
      
      <button
        onClick={() => handleNavigation('/profile')}
        className="flex items-center justify-center gap-2 w-full bg-gray-800/50 
                 hover:bg-gray-700/50 text-white rounded-xl p-3
                 border border-gray-700/50 transition-all duration-200
                 hover:border-gray-600/50"
      >
        <UserCircle className="h-4 w-4" />
        <span className="font-medium">Profile</span>
      </button>
    </div>
  );
};

export default QuickActions;