import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip } from "@/components/ui/chart";
import { Area, AreaChart, XAxis, YAxis } from "recharts";

const TrustScoreEvolution = () => {
  const { data: trustScoreData } = useQuery({
    queryKey: ["trustScoreEvolution"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data: payments, error } = await supabase
        .from("payments")
        .select("created_at, status")
        .eq("member_id", user.id)
        .order("created_at", { ascending: true });

      if (error) throw error;

      // Simulate trust score evolution based on payment history
      let score = 500; // Starting score
      return payments.map((payment) => {
        if (payment.status === 'completed') {
          score += 10;
        } else if (payment.status === 'late') {
          score -= 5;
        }
        return {
          date: new Date(payment.created_at).toLocaleDateString(),
          score: score,
        };
      });
    },
  });

  const chartConfig = {
    primary: {
      theme: {
        light: "#8884d8",
        dark: "#8884d8",
      },
    },
  };

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle>Trust Score Evolution</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ChartContainer config={chartConfig}>
            <AreaChart data={trustScoreData || []}>
              <XAxis
                dataKey="date"
                stroke="#888888"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="#888888"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <Area
                type="monotone"
                dataKey="score"
                stroke="#8884d8"
                fill="#8884d8"
                fillOpacity={0.2}
              />
              <ChartTooltip />
            </AreaChart>
          </ChartContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default TrustScoreEvolution;