import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip } from "@/components/ui/chart";
import { Line, LineChart, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";

const ContributionTrends = () => {
  const { data: paymentsData } = useQuery({
    queryKey: ["paymentTrends"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data, error } = await supabase
        .from("payments")
        .select("amount, created_at, status")
        .eq("member_id", user.id)
        .order("created_at", { ascending: true });

      if (error) throw error;

      // Process data for the chart
      return data.map((payment) => ({
        date: new Date(payment.created_at).toLocaleDateString(),
        amount: payment.amount,
        status: payment.status,
      }));
    },
  });

  const chartConfig = {
    primary: {
      theme: {
        light: "hsl(var(--primary))",
        dark: "hsl(var(--primary))",
      },
    },
  };

  return (
    <Card className="col-span-2">
      <CardHeader>
        <CardTitle>Contribution Trends</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ChartContainer config={chartConfig}>
            <LineChart data={paymentsData || []}>
              <XAxis
                dataKey="date"
                stroke="#888888"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="#888888"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `$${value}`}
              />
              <Line
                type="monotone"
                dataKey="amount"
                strokeWidth={2}
                activeDot={{ r: 6 }}
              />
              <ChartTooltip />
            </LineChart>
          </ChartContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default ContributionTrends;