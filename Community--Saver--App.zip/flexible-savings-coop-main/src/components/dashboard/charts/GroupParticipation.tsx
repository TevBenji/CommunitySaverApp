import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip } from "@/components/ui/chart";
import { Cell, Pie, PieChart } from "recharts";

const GroupParticipation = () => {
  const { data: participationData } = useQuery({
    queryKey: ["groupParticipation"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data: groups, error } = await supabase
        .from("group_members")
        .select(`
          savings_groups (
            id,
            name,
            group_members (count)
          )
        `)
        .eq("member_id", user.id);

      if (error) throw error;

      return groups.map((group: any) => ({
        name: group.savings_groups.name,
        value: group.savings_groups.group_members.count,
      }));
    },
  });

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];

  const chartConfig = {
    colors: {
      theme: {
        light: COLORS[0],
        dark: COLORS[0],
      },
    },
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Group Participation</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ChartContainer config={chartConfig}>
            <PieChart>
              <Pie
                data={participationData || []}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {(participationData || []).map((entry: any, index: number) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <ChartTooltip />
            </PieChart>
          </ChartContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default GroupParticipation;