import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface Profile {
  first_name?: string;
  last_name?: string;
}

interface SavingsGroup {
  name?: string;
}

interface Member {
  id: string;
  group_id: string;
  member_id: string;
  joined_at: string;
  profiles?: Profile;
  savings_groups?: SavingsGroup;
}

interface Payment {
  id: string;
  amount: number;
  profiles?: Profile;
  savings_groups?: SavingsGroup;
}

interface ActivityData {
  members: Member[];
  payments: Payment[];
}

const ActivityFeed = () => {
  const { data: activities } = useQuery({
    queryKey: ["activities"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return { members: [], payments: [] };

      // Fetch recent group members
      const { data: members } = await supabase
        .from("group_members")
        .select(`
          *,
          profiles:member_id (first_name, last_name),
          savings_groups:group_id (name)
        `)
        .order("joined_at", { ascending: false })
        .limit(5);

      // Fetch recent payments
      const { data: payments } = await supabase
        .from("payments")
        .select(`
          *,
          profiles:member_id (first_name, last_name),
          savings_groups:group_id (name)
        `)
        .order("created_at", { ascending: false })
        .limit(5);

      return {
        members: members || [],
        payments: payments || [],
      };
    },
  });

  const getInitials = (firstName?: string, lastName?: string) => {
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  return (
    <Card className="modern-card">
      <CardHeader className="p-3">
        <CardTitle className="text-sm font-medium">Recent Activity</CardTitle>
        <CardDescription className="text-xs">Latest updates from your groups</CardDescription>
      </CardHeader>
      <CardContent className="p-3 pt-0">
        <ScrollArea className="h-[200px] pr-2">
          <div className="space-y-2">
            {activities?.members?.map((member) => (
              <div
                key={member.id}
                className="flex items-center space-x-2 bg-white/40 dark:bg-white/5 p-2 rounded-lg"
              >
                <Avatar className="h-6 w-6">
                  <AvatarFallback className="text-xs bg-primary/10 text-primary">
                    {getInitials(
                      member.profiles?.first_name,
                      member.profiles?.last_name
                    )}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-xs font-medium">
                    {member.profiles?.first_name} {member.profiles?.last_name}
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    Joined {member.savings_groups?.name}
                  </p>
                </div>
              </div>
            ))}
            {activities?.payments?.map((payment) => (
              <div
                key={payment.id}
                className="flex items-center space-x-2 bg-white/40 dark:bg-white/5 p-2 rounded-lg"
              >
                <Avatar className="h-6 w-6">
                  <AvatarFallback className="text-xs bg-primary/10 text-primary">
                    {getInitials(
                      payment.profiles?.first_name,
                      payment.profiles?.last_name
                    )}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-xs font-medium">
                    {payment.profiles?.first_name} {payment.profiles?.last_name}
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    Made a payment of ${payment.amount} to{" "}
                    {payment.savings_groups?.name}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default ActivityFeed;