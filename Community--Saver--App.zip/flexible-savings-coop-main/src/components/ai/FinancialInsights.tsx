import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Brain, TrendingUp, AlertCircle, CheckCircle } from 'lucide-react';

interface InsightProps {
  type: 'success' | 'warning' | 'info';
  title: string;
  description: string;
}

const Insight: React.FC<InsightProps> = ({ type, title, description }) => {
  const iconMap = {
    success: CheckCircle,
    warning: AlertCircle,
    info: TrendingUp
  };

  const colorMap = {
    success: 'text-green-400 bg-green-500/20',
    warning: 'text-yellow-400 bg-yellow-500/20',
    info: 'text-blue-400 bg-blue-500/20'
  };

  const Icon = iconMap[type];

  return (
    <div className="p-4 rounded-lg bg-gray-800/40 border border-gray-700/30 transition-all duration-300 hover:bg-gray-800/60">
      <div className="flex items-start gap-4">
        <div className={`p-2 rounded-lg ${colorMap[type]}`}>
          <Icon className="w-5 h-5" />
        </div>
        <div className="flex-1">
          <h4 className="text-lg font-medium text-white mb-2">{title}</h4>
          <p className="text-gray-400">{description}</p>
        </div>
      </div>
    </div>
  );
};

const FinancialInsights: React.FC = () => {
  // Example insights - in a real app, these would be generated based on user data
  const insights: InsightProps[] = [
    {
      type: 'success',
      title: 'Savings Goal Progress',
      description: 'You\'re on track to meet your monthly savings target. Keep up the good work!'
    },
    {
      type: 'warning',
      title: 'Payment Due Soon',
      description: 'You have an upcoming group contribution due in 3 days. Consider scheduling it now.'
    },
    {
      type: 'info',
      title: 'Investment Opportunity',
      description: 'Based on your savings pattern, you might be ready to join a high-yield savings group.'
    }
  ];

  return (
    <Card className="bg-card-gradient-dark border border-gray-800/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Brain className="h-5 w-5 text-blue-400" />
          Financial Insights
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {insights.map((insight, index) => (
          <Insight key={index} {...insight} />
        ))}
      </CardContent>
    </Card>
  );
};

export default FinancialInsights;