import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Award, Trophy, Star } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";

const LeaderboardSection = () => {
  const { data: topUsers, isLoading: loadingUsers } = useQuery({
    queryKey: ["topUsers"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("first_name, last_name, trust_score")
        .order("trust_score", { ascending: false })
        .limit(5);

      if (error) throw error;
      return data;
    },
  });

  const { data: topGroups, isLoading: loadingGroups } = useQuery({
    queryKey: ["topGroups"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("savings_groups")
        .select(`
          id,
          name,
          group_tier,
          contribution_amount,
          group_members (count)
        `)
        .eq("status", "active")
        .order("contribution_amount", { ascending: false })
        .limit(5);

      if (error) throw error;
      return data;
    },
  });

  const getTrophyIcon = (position: number) => {
    switch (position) {
      case 0:
        return <Trophy className="h-5 w-5 text-yellow-500" />;
      case 1:
        return <Award className="h-5 w-5 text-gray-400" />;
      case 2:
        return <Star className="h-5 w-5 text-amber-700" />;
      default:
        return null;
    }
  };

  const getGroupTierColor = (tier: string) => {
    switch (tier?.toLowerCase()) {
      case "platinum":
        return "text-purple-600";
      case "gold":
        return "text-yellow-500";
      case "medium":
        return "text-blue-500";
      default:
        return "text-gray-500";
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
      {/* Trust Score Leaderboard */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            Top Savers
          </CardTitle>
          <CardDescription>Members with highest trust scores</CardDescription>
        </CardHeader>
        <CardContent>
          {loadingUsers ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">Rank</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead className="text-right">Trust Score</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topUsers?.map((user, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {getTrophyIcon(index)}
                        #{index + 1}
                      </div>
                    </TableCell>
                    <TableCell>
                      {user.first_name} {user.last_name}
                    </TableCell>
                    <TableCell className="text-right">
                      <span className="font-mono">
                        {user.trust_score}/1200
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Top Groups */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5 text-yellow-500" />
            Top Groups
          </CardTitle>
          <CardDescription>Most active savings groups</CardDescription>
        </CardHeader>
        <CardContent>
          {loadingGroups ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">Rank</TableHead>
                  <TableHead>Group</TableHead>
                  <TableHead className="text-right">Members</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topGroups?.map((group, index) => (
                  <TableRow key={group.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {getTrophyIcon(index)}
                        #{index + 1}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <span className="font-medium">{group.name}</span>
                        <div className="text-sm text-muted-foreground">
                          <span className={getGroupTierColor(group.group_tier)}>
                            {group.group_tier} Tier
                          </span>
                          {" • "}${group.contribution_amount} per cycle
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <span className="font-mono">
                        {(group.group_members as any)?.count || 0}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default LeaderboardSection;