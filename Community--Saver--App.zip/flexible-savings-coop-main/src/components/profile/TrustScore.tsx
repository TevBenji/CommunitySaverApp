import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";

interface TrustScoreProps {
  score: number;
}

const TrustScore = ({ score }: TrustScoreProps) => {
  const getTrustTier = (score: number) => {
    if (score >= 800) return { label: "Platinum", color: "bg-purple-500" };
    if (score >= 600) return { label: "Gold", color: "bg-yellow-500" };
    if (score >= 400) return { label: "Medium", color: "bg-blue-500" };
    return { label: "Low", color: "bg-gray-500" };
  };

  const tier = getTrustTier(score);
  const nextTierThreshold = score >= 800 ? 1000 : score >= 600 ? 800 : score >= 400 ? 600 : 400;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Trust Score</CardTitle>
        <CardDescription>Your current trust level and progress</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger>
                <Badge variant="outline" className={`${tier.color} text-white`}>
                  {tier.label} Tier
                </Badge>
              </TooltipTrigger>
              <TooltipContent>
                <p>Keep making on-time payments to increase your tier!</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <span className="text-sm text-muted-foreground">
            {score} / {nextTierThreshold}
          </span>
        </div>
        <Progress value={(score / nextTierThreshold) * 100} />
        <p className="text-sm text-muted-foreground">
          {score >= 800
            ? "Congratulations! You've reached the highest tier!"
            : `Reach ${nextTierThreshold} points to unlock the next tier!`}
        </p>
      </CardContent>
    </Card>
  );
};

export default TrustScore;