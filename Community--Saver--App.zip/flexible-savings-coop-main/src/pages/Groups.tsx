import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Plus, Users, Calendar, Wallet } from "lucide-react";
import { Loader2 } from "lucide-react";

interface Group {
  id: string;
  name: string;
  description: string | null;
  contribution_amount: number;
  frequency: string;
  min_trust_score: number | null;
  status: "active" | "completed" | "cancelled" | "not_started";
  banker_id: string;
  created_at: string;
  updated_at: string;
  group_tier: string | null;
  max_contributions: number | null;
}

const Groups = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [myGroups, setMyGroups] = useState<Group[]>([]);
  const [availableGroups, setAvailableGroups] = useState<Group[]>([]);

  useEffect(() => {
    fetchGroups();
  }, []);

  const fetchGroups = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate('/');
        return;
      }

      console.log('Fetching groups for user:', user.id);

      // Fetch groups where user is a member
      const { data: memberGroups, error: memberError } = await supabase
        .from('group_members')
        .select(`
          group_id,
          savings_groups (*)
        `)
        .eq('member_id', user.id);

      if (memberError) {
        console.error('Error fetching member groups:', memberError);
        throw memberError;
      }

      console.log('Raw member groups data:', memberGroups);

      // Extract the actual group objects and filter out any null values
      const userGroups = memberGroups
        ?.map(mg => mg.savings_groups)
        .filter((group): group is Group => {
          if (!group) {
            console.log('Filtered out null group');
            return false;
          }
          
          const hasRequiredProps = 
            'id' in group &&
            'name' in group &&
            'contribution_amount' in group &&
            'frequency' in group &&
            'banker_id' in group &&
            'created_at' in group &&
            'updated_at' in group;

          if (!hasRequiredProps) {
            console.log('Group missing required properties:', group);
            return false;
          }

          return true;
        }) || [];

      console.log('Processed member groups:', userGroups);

      // Get array of group IDs that the user is a member of
      const memberGroupIds = userGroups.map(g => g.id);
      console.log('Member group IDs:', memberGroupIds);

      // Fetch all active groups
      const { data: allActiveGroups, error: activeError } = await supabase
        .from('savings_groups')
        .select('*')
        .eq('status', 'active');

      if (activeError) {
        console.error('Error fetching available groups:', activeError);
        throw activeError;
      }

      console.log('All active groups:', allActiveGroups);

      // Filter out groups the user is already a member of
      const filteredAvailableGroups = allActiveGroups?.filter(
        group => !memberGroupIds.includes(group.id)
      ) || [];

      setMyGroups(userGroups);
      setAvailableGroups(filteredAvailableGroups);
      
      console.log('Final state:', { 
        myGroups: userGroups, 
        availableGroups: filteredAvailableGroups 
      });
    } catch (error: any) {
      console.error('Error fetching groups:', error);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-dark">
        <Loader2 className="h-8 w-8 animate-spin text-white" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-dark p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate('/dashboard')}
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
          <Button
            onClick={() => navigate('/create-group')}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Create New Group
          </Button>
        </div>

        <div className="space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-white mb-4">My Groups</h2>
            {myGroups.length === 0 ? (
              <Card className="bg-card-gradient-dark border-gray-800/50">
                <CardContent className="p-6">
                  <p className="text-gray-400">You haven't joined any groups yet.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {myGroups.map((group) => (
                  <Card 
                    key={group.id}
                    className="bg-card-gradient-dark border-gray-800/50 hover:border-gray-700/50 transition-colors cursor-pointer"
                    onClick={() => navigate(`/groups/${group.id}`)}
                  >
                    <CardHeader className="p-6">
                      <CardTitle className="text-xl text-white mb-2">{group.name}</CardTitle>
                      <p className="text-gray-400 text-sm">{group.description}</p>
                    </CardHeader>
                    <CardContent className="p-6 pt-0">
                      <div className="flex items-center gap-4 text-gray-300">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-2 text-blue-400" />
                          <span>{group.frequency}</span>
                        </div>
                        <div className="flex items-center">
                          <Wallet className="h-4 w-4 mr-2 text-green-400" />
                          <span>${group.contribution_amount}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Available Groups</h2>
            {availableGroups.length === 0 ? (
              <Card className="bg-card-gradient-dark border-gray-800/50">
                <CardContent className="p-6">
                  <p className="text-gray-400">No available groups to join at the moment.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {availableGroups.map((group) => (
                  <Card 
                    key={group.id}
                    className="bg-card-gradient-dark border-gray-800/50 hover:border-gray-700/50 transition-colors cursor-pointer"
                    onClick={() => navigate(`/groups/${group.id}`)}
                  >
                    <CardHeader className="p-6">
                      <CardTitle className="text-xl text-white mb-2">{group.name}</CardTitle>
                      <p className="text-gray-400 text-sm">{group.description}</p>
                    </CardHeader>
                    <CardContent className="p-6 pt-0">
                      <div className="flex items-center gap-4 text-gray-300">
                        <div className="flex items-center">
                          <Users className="h-4 w-4 mr-2 text-purple-400" />
                          <span>Min Trust: {group.min_trust_score}</span>
                        </div>
                        <div className="flex items-center">
                          <Wallet className="h-4 w-4 mr-2 text-green-400" />
                          <span>${group.contribution_amount}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};

export default Groups;