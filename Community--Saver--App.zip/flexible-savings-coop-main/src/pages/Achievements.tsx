import React, { useEffect, useState } from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Trophy, Star } from 'lucide-react';
import AchievementCard from '@/components/achievements/AchievementCard';
import { Achievement, achievements, checkAchievements } from '@/lib/achievements';
import { useToast } from '@/components/ui/use-toast';

interface UserAchievement {
  achievement_id: string;
  unlocked_at: string;
}

const Achievements = () => {
  const { toast } = useToast();
  const [unlockedAchievements, setUnlockedAchievements] = useState<string[]>([]);
  const [achievementProgress, setAchievementProgress] = useState<Record<string, number>>({});

  const { data: profile, isLoading: isProfileLoading, error: profileError } = useQuery({
    queryKey: ['profile'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;

      const { data, error } = await supabase
        .from('profiles')
        .select(`
          *,
          payments(amount, status, is_late),
          group_members(group_id)
        `)
        .eq('id', user.id)
        .single();

      if (error) throw error;
      return data;
    },
  });

  const { data: userAchievements, isLoading: isAchievementsLoading, error: achievementsError } = useQuery({
    queryKey: ['user-achievements'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data, error } = await supabase
        .from('user_achievements')
        .select('*')
        .eq('user_id', user.id);

      if (error) throw error;
      return data as { achievement_id: string; unlocked_at: string }[];
    },
  });

  useEffect(() => {
    if (userAchievements) {
      setUnlockedAchievements(userAchievements.map(ua => ua.achievement_id));
    }
  }, [userAchievements]);

  useEffect(() => {
    if (profile) {
      const progress: Record<string, number> = {};

      achievements.forEach(achievement => {
        switch (achievement.requirements.type) {
          case 'groups_joined': {
            progress[achievement.id] = Math.min(
              ((profile.group_members?.length || 0) / achievement.requirements.value) * 100,
              100
            );
            break;
          }
          case 'total_savings': {
            const totalSavings = profile.payments?.reduce((sum, p) => sum + (p.amount || 0), 0) || 0;
            progress[achievement.id] = Math.min(
              (totalSavings / achievement.requirements.value) * 100,
              100
            );
            break;
          }
          case 'trust_score': {
            progress[achievement.id] = Math.min(
              ((profile.trust_score || 0) / achievement.requirements.value) * 100,
              100
            );
            break;
          }
          case 'on_time_payments': {
            const onTimePayments = profile.payments?.filter(p => 
              p.status === 'completed' && !p.is_late
            )?.length || 0;
            progress[achievement.id] = Math.min(
              (onTimePayments / achievement.requirements.value) * 100,
              100
            );
            break;
          }
        }
      });

      setAchievementProgress(progress);
    }
  }, [profile]);

  const totalPoints = achievements
    .filter(a => unlockedAchievements.includes(a.id))
    .reduce((sum, a) => sum + a.points, 0);

  if (profileError || achievementsError) {
    if (isProfileLoading || isAchievementsLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Skeleton key={i} className="h-48" />
          ))}
        </div>
      </div>
    );
  }

  if (profileError || achievementsError) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          {profileError?.message || achievementsError?.message || 'An error occurred while loading achievements'}
        </AlertDescription>
      </Alert>
    );
  }

  return (
      <div className="min-h-screen bg-gradient-dark p-6 flex items-center justify-center">
        <div className="text-red-400 text-center">
          <p className="text-lg">Error loading achievements</p>
          <p className="text-sm">{(profileError || achievementsError)?.message}</p>
        </div>
      </div>
    );
  }

  if (isProfileLoading || isAchievementsLoading) {
    if (isProfileLoading || isAchievementsLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Skeleton key={i} className="h-48" />
          ))}
        </div>
      </div>
    );
  }

  if (profileError || achievementsError) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          {profileError?.message || achievementsError?.message || 'An error occurred while loading achievements'}
        </AlertDescription>
      </Alert>
    );
  }

  return (
      <div className="min-h-screen bg-gradient-dark p-6 flex items-center justify-center">
        <div className="text-white text-center">
          <p className="text-lg">Loading achievements...</p>
        </div>
      </div>
    );
  }

  if (isProfileLoading || isAchievementsLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Skeleton key={i} className="h-48" />
          ))}
        </div>
      </div>
    );
  }

  if (profileError || achievementsError) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          {profileError?.message || achievementsError?.message || 'An error occurred while loading achievements'}
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-dark p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-white">Achievements</h1>
          <div className="flex items-center gap-3 bg-gray-900/60 px-4 py-2 rounded-lg border border-gray-800/50">
            <Star className="w-5 h-5 text-yellow-400" />
            <span className="text-lg font-semibold text-white">{totalPoints} Points</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {achievements.map((achievement) => (
            <AchievementCard
              key={achievement.id}
              achievement={achievement}
              progress={achievementProgress[achievement.id] || 0}
              isUnlocked={unlockedAchievements.includes(achievement.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Achievements;