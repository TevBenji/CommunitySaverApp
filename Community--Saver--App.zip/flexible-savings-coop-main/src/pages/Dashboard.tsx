import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import TrustScore from "@/components/profile/TrustScore";
import QuickActions from "@/components/dashboard/QuickActions";
import ActivityFeed from "@/components/dashboard/ActivityFeed";
import AIAdvisor from "@/components/dashboard/AIAdvisor";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { 
  Loader2, 
  ChartBar, 
  Activity, 
  Search, 
  Users,
  TrendingUp,
  Plus,
  Wallet,
  Clock,
  AlertCircle,
  PiggyBank,
  UserRound,
  Star,
  Trophy,
  LayoutDashboard,
  Bot,
  MessageSquare,
  Menu
} from "lucide-react";
import SearchSection from "@/components/search/SearchSection";
import { useQuery } from "@tanstack/react-query";

const Dashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const { data: dashboardData, isLoading } = useQuery({
    queryKey: ["dashboard-data"],
    queryFn: async () => {
      console.log("Fetching dashboard data...");
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        navigate('/');
        return null;
      }

      // Fetch profile data
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select(`
          *,
          group_members(count),
          payments(amount)
        `)
        .eq('id', user.id)
        .single();

      if (profileError) {
        console.error("Profile fetch error:", profileError);
        throw profileError;
      }

      // Calculate total contributions from payments
      const totalContributions = profile?.payments?.reduce((sum: number, payment: { amount: number }) =>
        sum + (payment.amount || 0), 0) || 0;

      // Fetch upcoming payments
      const { data: upcomingPayments, error: paymentsError } = await supabase
        .from('payments')
        .select(`
          *,
          savings_groups (name)
        `)
        .eq('member_id', user.id)
        .eq('status', 'pending')
        .order('due_date', { ascending: true })
        .limit(5);

      if (paymentsError) {
        console.error("Payments fetch error:", paymentsError);
        throw paymentsError;
      }

      // Fetch recent activities
      const { data: recentActivities, error: activitiesError } = await supabase
        .from('group_members')
        .select(`
          *,
          savings_groups (name),
          profiles (first_name, last_name)
        `)
        .order('joined_at', { ascending: false })
        .limit(5);

      if (activitiesError) {
        console.error("Activities fetch error:", activitiesError);
        throw activitiesError;
      }

      return {
        profile: {
          ...profile,
          totalContributions
        },
        upcomingPayments: upcomingPayments || [],
        recentActivities: recentActivities || [],
      };
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-6 w-6 animate-spin text-white" />
      </div>
    );
  }

  const profile = dashboardData?.profile;
  const upcomingPayments = dashboardData?.upcomingPayments || [];
  const groupsJoined = profile?.group_members?.[0]?.count || 0;

  const formatCurrency = (amount: number) => {
    if (amount >= 1000) {
      return `$${(amount / 1000).toFixed(1)}k`;
    }
    return `$${amount.toFixed(0)}`;
  };

  return (
    <div className="min-h-screen bg-gradient-dark pt-16">
      <main className="max-w-7xl mx-auto px-2 sm:px-4 py-4 sm:py-6 space-y-4">
        {/* Stats Overview */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 sm:gap-3">
          <Card className="bg-card-gradient-dark border border-gray-800/50">
            <CardHeader className="p-2 sm:p-3">
              <CardTitle className="text-[11px] sm:text-xs text-white flex items-center gap-1">
                <Users className="h-3 w-3 text-blue-400" />
                Groups Joined
              </CardTitle>
            </CardHeader>
            <CardContent className="p-2 sm:p-3 pt-0">
              <p className="text-base sm:text-lg font-bold text-white">{groupsJoined}</p>
            </CardContent>
          </Card>

          <Card className="bg-card-gradient-dark border border-gray-800/50">
            <CardHeader className="p-2 sm:p-3">
              <CardTitle className="text-[11px] sm:text-xs text-white flex items-center gap-1">
                <Wallet className="h-3 w-3 text-green-400" />
                Total Contributions
              </CardTitle>
            </CardHeader>
            <CardContent className="p-2 sm:p-3 pt-0">
              <p className="text-base sm:text-lg font-bold text-white">${profile?.totalContributions || 0}</p>
            </CardContent>
          </Card>

          <Card className="bg-card-gradient-dark border border-gray-800/50">
            <CardHeader className="p-2 sm:p-3">
              <CardTitle className="text-[11px] sm:text-xs text-white flex items-center gap-1">
                <Clock className="h-3 w-3 text-yellow-400" />
                Upcoming Payments
              </CardTitle>
            </CardHeader>
            <CardContent className="p-2 sm:p-3 pt-0">
              <p className="text-base sm:text-lg font-bold text-white">{upcomingPayments.length}</p>
            </CardContent>
          </Card>

          <Card className="bg-card-gradient-dark border border-gray-800/50">
            <CardHeader className="p-2 sm:p-3">
              <CardTitle className="text-[11px] sm:text-xs text-white flex items-center gap-1">
                <AlertCircle className="h-3 w-3 text-red-400" />
                Overdue
              </CardTitle>
            </CardHeader>
            <CardContent className="p-2 sm:p-3 pt-0">
              <p className="text-base sm:text-lg font-bold text-white">
                {upcomingPayments.filter(p => new Date(p.due_date) < new Date()).length}
              </p>
            </CardContent>
          </Card>

          <Card className="bg-card-gradient-dark border border-gray-800/50">
            <CardHeader className="p-2 sm:p-3">
              <CardTitle className="text-[11px] sm:text-xs text-white flex items-center gap-1">
                <PiggyBank className="h-3 w-3 text-purple-400" />
                Savings
              </CardTitle>
            </CardHeader>
            <CardContent className="p-2 sm:p-3 pt-0">
              <p className="text-base sm:text-lg font-bold text-white">
                {formatCurrency((profile?.totalContributions || 0) * 1.1)}
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 sm:gap-4">
          {/* Trust Score and Search Section */}
          <div className="space-y-3 sm:space-y-4">
            <Card className="dashboard-card">
              <CardHeader className="p-3 sm:p-4">
                <CardTitle className="text-sm sm:text-base text-white">Trust Score Overview</CardTitle>
                <CardDescription className="text-gray-400 text-xs">
                  Your current standing and privileges
                </CardDescription>
              </CardHeader>
              <CardContent className="p-3 sm:p-4 pt-0">
                <TrustScore score={profile?.trust_score || 300} />
              </CardContent>
            </Card>

            <Card className="dashboard-card">
              <CardHeader className="p-3 sm:p-4">
                <CardTitle className="flex items-center gap-1 text-sm sm:text-base text-white">
                  <Search className="h-3 w-3" />
                  Find Groups
                </CardTitle>
                <CardDescription className="text-gray-400 text-xs">
                  Search for savings groups that match your interests
                </CardDescription>
              </CardHeader>
              <CardContent className="p-3 sm:p-4 pt-0">
                <SearchSection />
                <Button
                  onClick={() => navigate('/create-group')}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white
                           py-1.5 text-xs rounded-lg shadow-sm mt-3 mb-3
                           transition-all duration-300 hover:shadow-md
                           border border-blue-500/50
                           h-8 text-[11px] sm:text-xs"
                >
                  <Plus className="h-3 w-3 mr-1.5" />
                  Create New Group
                </Button>
                
                <div className="grid grid-cols-2 gap-2 sm:gap-3">
                  {navigationCards.map((card) => (
                    <button
                      key={card.path}
                      onClick={() => navigate(card.path)}
                      className="nav-card group text-left p-2 sm:p-3"
                    >
                      <div className={`nav-icon p-1.5 mb-2 ${card.bgColor} ${card.iconColor}`}>
                        <card.icon className="h-3.5 w-3.5" />
                      </div>
                      <h3 className="text-[11px] sm:text-xs font-semibold mb-1 text-white">{card.title}</h3>
                      <p className="text-[10px] sm:text-[11px] text-gray-300 leading-tight">{card.description}</p>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Activity Feed, AI Advisor, and Quick Actions */}
          <div className="space-y-3 sm:space-y-4">
            <ActivityFeed />
            <AIAdvisor />
            <QuickActions />
          </div>
        </div>
      </main>
    </div>
  );
};

const navigationCards = [
  {
    title: "Analytics & Insights",
    description: "View detailed financial analytics and trends",
    icon: ChartBar,
    path: "/analytics",
    iconColor: "text-blue-400",
    bgColor: "bg-blue-500/10",
  },
  {
    title: "Activity Center",
    description: "Check recent activities and AI recommendations",
    icon: Activity,
    path: "/activity",
    iconColor: "text-green-400",
    bgColor: "bg-green-500/10",
  },
  {
    title: "Group Management",
    description: "Manage your savings groups and memberships",
    icon: Users,
    path: "/groups",
    iconColor: "text-purple-400",
    bgColor: "bg-purple-500/10",
  },
  {
    title: "Payment History",
    description: "Track your contributions and payments",
    icon: TrendingUp,
    path: "/payments",
    iconColor: "text-orange-400",
    bgColor: "bg-orange-500/10",
  },
];

export default Dashboard;