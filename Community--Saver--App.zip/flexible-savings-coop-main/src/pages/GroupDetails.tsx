import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, Users, Calendar, Wallet, Trophy, ArrowLeft } from "lucide-react";

const GroupDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [group, setGroup] = useState<any>(null);
  const [members, setMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState(false);

  useEffect(() => {
    fetchGroupDetails();
  }, [id]);

  const fetchGroupDetails = async () => {
    try {
      const { data: groupData, error: groupError } = await supabase
        .from('savings_groups')
        .select('*')
        .eq('id', id)
        .single();

      if (groupError) throw groupError;

      const { data: membersData, error: membersError } = await supabase
        .from('group_members')
        .select(`
          *,
          profiles:member_id (
            first_name,
            last_name,
            trust_score
          )
        `)
        .eq('group_id', id);

      if (membersError) throw membersError;

      setGroup(groupData);
      setMembers(membersData);
      console.log('Group details loaded:', { group: groupData, members: membersData });
    } catch (error: any) {
      console.error('Error fetching group details:', error);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleJoinGroup = async () => {
    try {
      setJoining(true);
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        navigate('/');
        return;
      }

      const { error } = await supabase
        .from('group_members')
        .insert({
          group_id: id,
          member_id: user.id,
          role: 'member'
        });

      if (error) throw error;

      toast({
        title: "Success!",
        description: "You have successfully joined the group.",
      });
      
      fetchGroupDetails();
    } catch (error: any) {
      console.error('Error joining group:', error);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setJoining(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <Loader2 className="h-8 w-4 animate-spin text-primary" />
      </div>
    );
  }

  if (!group) {
    return (
      <div className="min-h-screen bg-background p-8">
        <Card className="max-w-2xl mx-auto p-6">
          <h1 className="text-2xl font-bold text-primary mb-4">Group Not Found</h1>
          <Button onClick={() => navigate('/dashboard')} variant="outline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <Button 
          onClick={() => navigate('/dashboard')} 
          variant="outline"
          className="mb-6"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Dashboard
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 p-6 bg-card">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h1 className="text-3xl font-bold text-primary mb-2">{group.name}</h1>
                <p className="text-muted-foreground">{group.description || 'No description available'}</p>
              </div>
              <span className="px-3 py-1 bg-secondary/10 text-secondary rounded-full text-sm">
                {members.length} members
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-card/50 p-4 rounded-lg border border-border">
                <div className="flex items-center mb-2">
                  <Calendar className="h-5 w-5 mr-2 text-primary" />
                  <span className="text-sm text-muted-foreground">Frequency</span>
                </div>
                <p className="text-2xl font-bold text-primary">{group.frequency}</p>
              </div>

              <div className="bg-card/50 p-4 rounded-lg border border-border">
                <div className="flex items-center mb-2">
                  <Wallet className="h-5 w-5 mr-2 text-primary" />
                  <span className="text-sm text-muted-foreground">Contribution</span>
                </div>
                <p className="text-2xl font-bold text-primary">
                  ${group.contribution_amount}
                </p>
              </div>

              <div className="bg-card/50 p-4 rounded-lg border border-border">
                <div className="flex items-center mb-2">
                  <Trophy className="h-5 w-5 mr-2 text-primary" />
                  <span className="text-sm text-muted-foreground">Min Trust Score</span>
                </div>
                <p className="text-2xl font-bold text-primary">{group.min_trust_score}</p>
              </div>
            </div>

            <Button 
              onClick={handleJoinGroup} 
              className="w-full bg-primary hover:bg-primary/90 transition-colors"
              disabled={joining}
            >
              {joining ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Joining...
                </>
              ) : (
                <>
                  <Users className="mr-2 h-4 w-4" />
                  Join Group
                </>
              )}
            </Button>
          </Card>

          <Card className="p-6 bg-card">
            <h2 className="text-xl font-bold text-primary mb-4 flex items-center">
              <Users className="mr-2 h-5 w-5" />
              Members
            </h2>
            <div className="space-y-4">
              {members.map((member) => (
                <div 
                  key={member.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-card/50 border border-border"
                >
                  <div>
                    <p className="font-medium text-primary">
                      {member.profiles.first_name} {member.profiles.last_name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {member.role === 'banker' ? 'Group Banker' : 'Member'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-primary">
                      Trust Score
                    </p>
                    <p className="text-muted-foreground">
                      {member.profiles.trust_score}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default GroupDetails;