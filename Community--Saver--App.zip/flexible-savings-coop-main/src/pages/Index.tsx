import AuthForm from "@/components/auth/AuthForm";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-dark py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-6">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gradient mb-2">Community Savings</h1>
          <p className="text-primary text-lg">Save together, grow together</p>
        </div>
        <AuthForm />
      </div>
    </div>
  );
};

export default Index;