import { useNavigate } from "react-router-dom";
import CreateGroup from "@/components/groups/CreateGroup";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

const CreateGroupPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-soft dark:bg-gradient-dark p-4 md:p-8">
      <Button
        variant="ghost"
        onClick={() => navigate(-1)}
        className="mb-6"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back
      </Button>
      <div className="max-w-2xl mx-auto">
        <CreateGroup />
      </div>
    </div>
  );
};

export default CreateGroupPage;