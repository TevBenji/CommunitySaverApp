import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import ActivityFeed from "@/components/dashboard/ActivityFeed";
import AIAdvisor from "@/components/dashboard/AIAdvisor";

const Activity = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-soft dark:bg-gradient-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Button 
          variant="outline" 
          onClick={() => navigate(-1)}
          className="mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>

        <h1 className="text-3xl font-medium mb-8">Activity & AI Insights</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ActivityFeed />
          <AIAdvisor />
        </div>
      </div>
    </div>
  );
};

export default Activity;