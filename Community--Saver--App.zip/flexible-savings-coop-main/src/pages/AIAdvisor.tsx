import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Brain, Send, ArrowLeft, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import FinancialInsights from '@/components/ai/FinancialInsights';

const AIAdvisor = () => {
  const navigate = useNavigate();
  const [message, setMessage] = useState('');
const [conversation, setConversation] = useState<Array<{ role: "user" | "assistant"; content: string }>>([]);
  const [isLoading, setIsLoading] = useState(false);

  const { data: profile } = useQuery({
    queryKey: ['profile'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      
      const { data, error } = await supabase
        .from('profiles')
        .select(`
          *,
          payments(amount, status),
          group_members(group_id)
        `)
        .eq('id', user.id)
        .single();
      
      if (error) throw error;
      return data;
    },
  });

  const sendMessage = async () => {
    if (!message.trim() || isLoading) return;

    try {
      setIsLoading(true);
      const newConversation = [...conversation, { role: "user" as const, content: message }];
      setConversation(newConversation);
      setMessage('');

      const context = `
        User Profile:
        - Trust Score: ${profile?.trust_score || 0}
        - Groups Joined: ${profile?.group_members?.length || 0}
        - Total Savings: ${profile?.payments?.reduce((sum, p) => sum + (p.amount || 0), 0) || 0}
      `;

      const { data, error } = await supabase.functions.invoke('ai-advisor', {
        body: {
          messages: newConversation,
          context: context
        }
      });

      if (error) throw error;

      setConversation([...newConversation, { 
        role: "assistant" as const,
        content: data.choices[0].message.content 
      }]);
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-dark p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <Button 
          variant="outline" 
          onClick={() => navigate(-1)}
          className="mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="bg-card-gradient-dark border border-gray-800/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Brain className="h-5 w-5 text-blue-400" />
                  AI Financial Advisor
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[400px] overflow-y-auto mb-4 space-y-4 px-2">
                  {conversation.map((msg, index) => (
                    <div
                      key={index}
                      className={`p-4 rounded-lg ${msg.role === 'assistant' ? 
                        'bg-blue-500/10 border border-blue-500/20' : 
                        'bg-gray-500/10 border border-gray-500/20'}`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-full ${msg.role === 'assistant' ? 
                          'bg-blue-500/20' : 'bg-gray-500/20'}`}>
                          {msg.role === 'assistant' ? 
                            <Brain className="h-5 w-5 text-blue-400" /> : 
                            <div className="h-5 w-5 rounded-full bg-gray-400" />}
                        </div>
                        <div className="flex-1 space-y-2">
                          <div className="font-medium text-sm text-gray-400">
                            {msg.role === 'assistant' ? 'AI Advisor' : 'You'}
                          </div>
                          <div className="text-gray-100 whitespace-pre-wrap text-sm leading-relaxed">
                            {msg.content.split('###').map((section, idx) => {
                              if (idx === 0) return section;
                              const [title, ...content] = section.split('-');
                              return (
                                <div key={idx} className="mt-4">
                                  <h3 className="text-blue-400 font-medium mb-2">{title.trim()}</h3>
                                  <p>{content.join('-').trim()}</p>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex gap-3 items-end">
                  <Textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Ask for financial advice..."
                    className="min-h-[80px] bg-gray-900/50 border-gray-700 resize-none"
                  />
                  <Button
                    onClick={sendMessage}
                    disabled={isLoading || !message.trim()}
                    className="h-10 px-4 bg-blue-600 hover:bg-blue-700"
                  >
                    {isLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-1">
            <FinancialInsights />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIAdvisor;