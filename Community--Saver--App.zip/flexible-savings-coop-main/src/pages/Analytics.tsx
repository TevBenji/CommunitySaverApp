import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import ContributionTrends from "@/components/dashboard/charts/ContributionTrends";
import GroupParticipation from "@/components/dashboard/charts/GroupParticipation";
import TrustScoreEvolution from "@/components/dashboard/charts/TrustScoreEvolution";

const Analytics = () => {
  const navigate = useNavigate();

  const { isLoading: isUserLoading, error: userError } = useQuery({
    queryKey: ['currentUser'],
    queryFn: async () => {
      const { data: { user }, error } = await supabase.auth.getUser();
      if (error) throw error;
      return user;
    },
  });

  if (isUserLoading) {
    return (
      <div className="min-h-screen bg-gradient-soft dark:bg-gradient-dark p-8">
        <Skeleton className="h-8 w-32 mb-8" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-[300px]" />
          ))}
        </div>
      </div>
    );
  }

  if (userError) {
    return (
      <div className="min-h-screen bg-gradient-soft dark:bg-gradient-dark p-8">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {userError.message || 'An error occurred while loading analytics'}
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-soft dark:bg-gradient-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Button 
          variant="outline" 
          onClick={() => navigate(-1)}
          className="mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>

        <h1 className="text-3xl font-medium mb-8">Analytics & Insights</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <ContributionTrends />
          <GroupParticipation />
        </div>
        <div className="mb-8">
          <TrustScoreEvolution />
        </div>
      </div>
    </div>
  );
};

export default Analytics;